# Memelang v7

Memelang is an ultra-token-efficient language for querying structured data, knowledge graphs, and retrieval-augmented generation pipelines.

## Memes

### Meme
* Comprises key-value pairs `key=value`
* Pairs must be separated by whitespaces `\s+`
* First pair always identifies the meme `m=<id>`
* Must terminate with semicolon `;`

### Key
* Is an alphanumeric string `movie`

### Value
* Either integer `123`
* or float `45.6`
* or unquoted alphanumeric string `Leia`
* or CSV-style double quoted string `"John ""Jack"" Kennedy"`

### Comment
* Prefixed with double forward slashes `//`
* Terminated with newline `\n`

### Example Memes

```memelang
m=100 actor="Mark Hamill" role="Luke Skywalker" movie="Star Wars" rating=4.5;
m=101 actor="Harrison Ford" role="Han Solo" movie="Star Wars" rating=4.6;
m=102 actor="Carrie Fisher" role=Leia movie="Star Wars" rating=4.2;

m=110 actor="Mark Hamill" role=Joker movie="Batman: Mask of the Phantasm" rating=4.7;
m=111 actor="Harrison Ford" role="Indiana Jones" movie="Raiders of the Lost Ark" rating=4.8;
m=112 actor="Carrie Fisher" role=Marie movie="When Harry Met Sally" rating=4.3;

m=200 person="Mark Hamill" birthyear=1951 birthplace="Oakland, CA";
m=201 person="Harrison Ford" birthyear=1942 birthplace="Chicago, IL";
m=202 person="Carrie Fisher" birthyear=1956 birthplace="Burbank, CA";

m=300 place="Oakland, CA" population=433000 climate=Mediterranean foundedyear=1852;
m=301 place="Chicago, IL" population=2740000 climate="Humid Continental" foundedyear=1833;
m=302 place="Burbank, CA" population=105000 climate=Mediterranean foundedyear=1887;
```

### EBNF Memes

The EBNF below is a machine-readable description of stored memes.

```EBNF
(* Memelang v7 *)
memelang	::= { meme } ;
meme		::= mid { WS+ pair } WS* ';' ( WS | comment )* ;
mid			::= 'm' '=' id ;
pair		::= key '=' value ;
key			::= ALNUM+ ;
id			::= DIGIT+ ;
value		::= ['-'] DIGIT+ ['.' DIGIT+]? | ALNUM+ | quoted ;
quoted		::= '"' ( CHAR | '""' )* '"' ;
comment		::= '//' CHAR* ( '\n' | EOF ) ;
ALNUM		::= 'A'..'Z' | 'a'..'z' | DIGIT | '_' ;
DIGIT		::= '0'..'9' ;
WS			::= ' ' | '\t' | '\r' | '\n' ;
CHAR		::= ? any Unicode character except '"' or '\n' ? ;
```

## Queries

Queries are memes with uncertainty. The meme pair format `key=value` is a special *certainty* case of the more general query pair format `<keyopr><keys><valopr><values>`. Each query pair returns at least one certainty pair in the result.

### Key Operator (keyopr)
* *none* matches the listed keys `k=v`
* `!` matches any *except* the listed keys `!k=v`

### Keys
* Single **key** matches exactly `k=v`
* Wildcard matches any **key** for given **values** `*=v`
* Comma-separated list of **keys** matches any listed key `role,actor=v`
* Variable (explained below)

### Value Operator (valopr)
* `=`
* `!=`
* `>`
* `>=`
* `<`
* `<=`

### Values
* Single **value** matches exactly `k=v`
* Wildcard matches any **value** for given **keys** `k=*`
* Comma-separated list of **values** matches any listed value `k=Mark,"Mark Hamill"`
* Variable (explained below)


### Example Queries

```memelang
// Query for all movies with Mark Hamill as an actor
actor="Mark Hamill" movie=* role=*;

// Response
m=100 actor="Mark Hamill" movie="Star Wars" role="Luke Skywalker";
m=110 actor="Mark Hamill" movie="Batman: Mask of the Phantasm" role=Joker;
```
```memelang
// Query for all relations and values from all memes relating to Mark Hamill
// All pairs in the meme match for *=*
*="Mark Hamill" *=*;
```
```memelang
// Query for value inequalities
population>100000 place=*;
rating>=4.3 rating<=4.7 actor=* role=*;
```

### Example OR/Negation Queries
* `!` key operator negates all **keys** in the list
* `!=` value operator negates all **values** in the list

```memelang
// OR–list semantics in set notation
K1,K2=V1,V2;	// (key ∈ {K1,K2}) ∧ (value ∈ {V1,V2})
K1,K2!=V1,V2;	// (key ∈ {K1,K2}) ∧ (value ∉ {V1,V2})
!K1,K2=V1,V2;	// (key ∉ {K1,K2}) ∧ (value ∈ {V1,V2})
!K1,K2!=V1,V2;	// (key ∉ {K1,K2}) ∧ (value ∉ {V1,V2})
!K1,K2>V1;		// (key ∉ {K1,K2}) ∧ (value > V1)
```
```memelang
// Query for (actor OR role) = ("Luke Skywalker" OR "Mark Hamill")
actor,role="Luke Skywalker","Mark Hamill" movie=*;
```
```memelang
// Query for actors who are not Mark Hamill or Carrie Fisher
actor!="Mark Hamill","Carrie Fisher" role=* movie=*;
```
```memelang
// Query for Mark Hamill for all keys except actor and role
!actor,role="Mark Hamill" movie=*;
```

### EBNF Queries

The continued EBNF below is a machine-readable description of query pairs.

```EBNF
(* Memelang v7 - reuse grammar above *)
qmemelang	::= { qmeme } ;
qmeme		::= qpair { WS+ qpair } WS* ';' ( WS | comment )* ;
qpair 		::= pair | qkv ;
qkv			::= [keyopr] keys valopr values;
keys 		::= '*' | qkey {',' qkey} ;
values		::= '*' | qvalue {',' qvalue} ;
keyopr		::= '!' ;
valopr		::= '=' | '!=' | '<' | '<=' | '>' | '>=';
qkey		::= key | var ;
qvalue		::= value | var ;
var			::= '@' NZDIGIT* | '#' NZDIGIT* | '$' ALNUM+ [ ':' NZDIGIT+ ];
NZDIGIT		::= '1'..'9' ;
```

## Variables

Passing strictly left to right, each pair pushes its returned **key** (string) and **value** (integer/float/string) to three parallel LIFO stacks. Variables let later pairs retrieve the integers/floats/strings in those stacks. The stacks resets at a `;`. Variables *cannot* be assigned. Variables *cannot*  forward-reference. Variables *cannot* reference objects or properties of values. Variables *cannot* be inside quotes. The stacks are read-only and do not pop.

Simplified variable model in python:
```python
key_stack = []
value_stack = []
keyname_stack = {}

def stack_add(key, value):
	key_stack.append(key)
	value_stack.append(value)
	keyname_stack.setdefault(key.lower(), []).append(value)

def slot_get(tok):
	if len(tok)==1: return 1
	slot=int(tok[1:])
	if not slot: raise Exception()
	return -1 * slot

def stack_get(tok):
	if tok.startswith('#'): return key_stack[slot_get(tok)]
	if tok.startswith('@'): return value_stack[slot_get(tok)]
	if tok.startswith('$'):
		name, p, d = tok[1:].partition(':')
		name = name.lower() # case-insensitive
		return keyname_stack[name][slot_get(p+d)]
```

### Stack Slots
* 𝑛 retrieves the 𝑛th pair prior
* 𝑛=0 retrieves the current pair (*illegal*)
* 𝑛=1 retrieves one pair prior (implicit default when 𝑛 omitted)
* 𝑛=2 retrieves two pairs prior
* ***EVERY*** query pair counts as a slot including `m` pairs below

### Stack Keynames
* `$keyname:𝑛` retrieves the **value** from the 𝑛th most recent `keyname` pair
* `$keyname` and `$keyname:1` retrieve the **value** from the most recent `keyname` pair
* *Only* stacks when **key** is a single string (no `*` `!` `,`)
* Case-insensitive

### Stack Keys
* `#𝑛` retrieves the **key** from the 𝑛th pair back
* `#` and `#1` retrieve **key** from one pair back
* `#2` retrieves the **key** from 2 pairs back
* `#3` retrieves the **key** from 3 pairs back
* Always stacks, even when **key** is uncertain

### Stack Values
* `@𝑛` retrieves the **value** from the 𝑛th pair back
* `@` and `@1` retrieve the **value** from one pair back 
* `@2` retrieves the **value** from 2 pairs back
* `@3` retrieves the **value** from 3 pairs back
* Always stacks, even when **key** is uncertain


### Stack Examples

Demonstration of how the variable stacks grow while processing the query:

```memelang
movie="Star Wars" role=* *=4.5
```

| After the pair      | `@` stack                               | `#` stack                            | `keyname_stack` dict                                     |
| ------------------- | --------------------------------------- | ------------------------------------ | -------------------------------------------------------- |
| `movie="Star Wars"` | ['Star Wars']                          | ['movie']                           | {'movie': ['Star Wars']}                                |
| `role=*`            | ['Star Wars', *returned_value*]      | ['movie', 'role']                   | {'movie': ['Star Wars'], 'role': [*returned_value*]} |
| `*=4.5`             | ['Star Wars', *returned_value*, 4.5] | ['movie', 'role', *returned_key*] | *(unchanged, **key** is uncertain)* |


### Variable Examples

Variables are primarily used in joins (section below). However, variables occasionally retrieve a pair from the current meme. Below are unusual examples of retrieving from the current meme (expert only, avoid)

```memelang
// Query for titular roles whose value equals the movie title
role=* movie=@ actor=*;
role=* movie=$role actor=*;
role=* actor=* movie=@2;
role=* actor=* movie=$role;
```
```memelang
// Variables may be used in comma lists
role=* movie=@,"Star Wars";
```
```memelang
// Variables may swap value into key name
K1=* @=V2; // @ must be alphanumeric
K1=* $K1=V2;
```
```memelang
// Variables may swap key name into value
*=V1 K2=#;
```

## Joins

Distinct items (actors, movies, etc.) usually occupy distinct memes with unique `m=id` identifiers. By default, a pair stays within the current meme. A join query matches multiple memes by specifying a pair with **key** `m`, allowing the next pair to match a different meme.
* `m` **key** in a pair specifies which memes to join next
* `$m` is automatically stacked with the current `m=<id>`
* `m=$m` and `m=$m:1` stay in current meme (implicit default)
* `m!=$m` join to a different meme
* `m=*` join to any meme (current or different)


### Join Variables

*Always* after an `m` pair, the following pair retrieves an uncertain pair from the prior meme. Generally using `$keyname` is preferred. When `$keyname` is not populated, the correct **value** variable is typically `@2`. Retrieved **values** must be semantically similar to the current key's **values**, such as person-person or year-year *not* person-year.

### Distinct Joins

```memelang
// The most common join is distinct
K1=* m!=$m K2=$K1
```
Explained:
* `K1=*` a first meme has a pair
	* **key** equals `K1`
	* any **value** stacks in `$K1`
* `m!=$m` requires the following pair matches a *distinct* meme identifier
* `K2=$K1` requires the second meme has a pair 
	* **key** equals `K2` 
	* **value** equals `K1`'s **value** as stacks in `$K1`

Note `m!=$m` joins to *distinct* memes, so trailing distinct conditionals like `actor!=$actor` are redundant and unnecessary.


### Indistinct Joins

```memelang
// Wildcard allows the current meme in the second joined meme 
K1=* m=* K2=$K1
```

### Wildcard Key Joins

```memelang
// Wildcards in keys
*=* m!=$m *=@2
```
Explained:
* `*=*` matches every **key** and **value** in a first meme
	* **value** stacks in `@`
* `m!=$m` requires the following pair matches a *distinct* meme identifier
* `*=@2` requires the second meme has a pair with 
	* **key** equals anything
	* **value** equals `@2` the **value** two pairs back (from `*=*`)
* The second meme's `m=id` is implicitly automatically stacks in `$m`

### Join Examples

```memelang
// Query for all of Mark Hamill's costars - see how @2 and @3 and $movie each retrieve movie=* in their respective queries
actor="Mark Hamill" movie=* m!=$m movie=$movie actor=*;
movie=* actor="Mark Hamill" m!=$m movie=$movie actor=*;
actor="Mark Hamill" movie=* m!=$m movie=@2 actor=*; // @2 retrieves movie=*
movie=* actor="Mark Hamill" m!=$m movie=@3 actor=*; // @3 retrieves movie=* (note actor="Mark Hamill" intervenes)

// Response - join queries return combined memes, each pair belongs to the preceding m=<id>
m=100 actor="Mark Hamill" movie="Star Wars" m=101 movie="Star Wars" actor="Harrison Ford";
m=100 actor="Mark Hamill" movie="Star Wars" m=102 movie="Star Wars" actor="Carrie Fisher";
```
```memelang
// Query for the actor's birthplace
actor=* m!=$m person=$actor birthplace=*;
actor=* m!=$m person=@2 birthplace=*;
```
```memelang
// Query for people born in the year their birthplace was founded - join on int birthyear is year = foundedyear is year
person=* birthyear=* m!=$m foundedyear=$birthyear place=*;
person=* birthyear=* m!=$m foundedyear=@2 place=*;
```
```memelang
// Query for every meme related to any value related to Mark Hamill - wild join keys (expert, avoid)
actor="Mark Hamill" *=* m!=$m *=@2 *=*;
```

### Multi-join Examples

```memelang
// Query for the other movies Mark Hamill's costars have acted in - multi join
actor="Mark Hamill" movie=* m!=$m movie=$movie actor=* m!=$m actor=$actor movie=*;
actor="Mark Hamill" movie=* m!=$m movie=@2 actor=* m!=$m actor=@2 movie=*;
```
```memelang
// Query for the population of the birthplace of the Star Wars cast
movie="Star Wars" actor=* m!=$m person=$actor birthplace=* m!=$m place=$birthplace population=*;
movie="Star Wars" actor=* m!=$m person=@2 birthplace=* m!=$m place=@2 population=*;
```
```memelang
// Query for cities older than Burbank and with larger populations - inequality join
place="Burbank, CA" foundedyear=* population=* m!=$m population>$population foundedyear<$foundedyear place=*;
place="Burbank, CA" foundedyear=* population=* m!=$m population>@2 foundedyear<@4 place=*; // In this example @4 = 1887 (Burbank foundedyear)
```

## Errors 

### Syntax Errors

```memelang
// Syntax Error - cannot chain values
K1=V1=V2;
```
```memelang
// Syntax Error - missing spaces between pairs
K1=*K2=*K3=X;
```
```memelang
// Syntax Error - cannot mix wildcard and commas
K1=*,V1,V2;
```
```memelang
// Warning - wildcard inside quotes - becomes literal "*"
actor="*";

// Likely meant
actor=*;
```
```memelang
// Warning - variable inside quotes
person=* m!=$m actor="$person";

// Likely meant
person=* m!=$m actor=$person;
```

### Join Errors

```memelang
// Warning - missing m= pair in join
movie=* movie=@;

// Likely meant
movie=* m!=$m movie=@2;
```
```memelang
// Warning - missing retrieved variable
movie=* m!=$m actor=*;

// Likely meant
movie=* m!=$m movie=@2 actor=*;
```
```memelang
// Warning - wrong slot - @ retrieves m!=$m pair
movie=* m!=$m movie=@;

// Likely meant
movie=* m!=$m movie=@2;
```
```memelang
// Warning - wrong slot  - @1 retrieves m!=$m pair
movie=* m!=$m movie=@1;

// Likely meant
movie=* m!=$m movie=@2;
```
```memelang
// Warning - must join similar values - actor is person != birthplace is place
birthplace=* person=* m!=$m actor=$birthplace;

// Likely meant
person=* m!=$m actor=$person birthplace=*;
```
```memelang
// Semantic Error - undefined variable $director
movie=* m!=$m actor=$director;

// Likely meant
director=* movie=* m!=$m actor=$director;
```
```memelang
// Semantic Error - undefined variable $director:2 - wrong variable slot
director=* movie=* m!=$m actor=$director:2;

// Likely meant
director=* movie=* m!=$m actor=$director;
```

## SQL Comparisons

Memelang queries are significantly shorter and clearer than equivalent SQL queries.

```
actor=* role="Luke Skywalker","Han Solo" rating>4;
SELECT actor FROM movies WHERE role IN ('Luke Skywalker', 'Han Solo') AND rating > 4;
```
```
person,actor="Mark Hamill","Harrison Ford" movie=* m!=$m movie=$movie actor=*;
SELECT m1.actor, m1.movie, m2.actor FROM movies m1 JOIN movies m2 ON m1.movie = m2.movie WHERE m1.person IN ('Mark Hamill', 'Harrison Ford') AND m1.actor IN ('Mark Hamill', 'Harrison Ford');
```

## Credits

Memelang was created by [Bri Holt](https://en.wikipedia.org/wiki/Bri_Holt) in a [2023 U.S. Provisional Patent application](https://patents.google.com/patent/US20250068615A1). ©2025 HOLTWORK LLC. Contact [info@memelang.net](mailto:info@memelang.net).