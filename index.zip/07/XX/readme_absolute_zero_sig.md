# Memelang v7

Memelang is a token-efficient language for querying structured data, knowledge graphs, and retrieval-augmented generation pipelines.

## Memes

### Meme
* Comprises key-value pairs `key=value`
* Pairs must be separated by whitespaces `\s+`
* First pair always identifies the meme `m=<id>`
* Must terminate with semicolon `;`

### Key
* Is an alphanumeric string `movie`

### Value
* Either integer `123`
* or float `45.6`
* or unquoted alphanumeric string `Leia`
* or CSV-style double quoted string `"John ""Jack"" Kennedy"`

### Comment
* Prefixed with double forward slashes `//`
* Terminated with newline `\n`

Note that integers and floats *cannot* start with a leading zero. Leading zeros are reserved for variables (below).

### Example Memes

```memelang
m=100 actor="Mark Hamill" role="Luke Skywalker" movie="Star Wars" rating=4.5;
m=101 actor="Harrison Ford" role="Han Solo" movie="Star Wars" rating=4.6;
m=102 actor="Carrie Fisher" role=Leia movie="Star Wars" rating=4.2;

m=110 actor="Mark Hamill" role=Joker movie="Batman: Mask of the Phantasm" rating=4.7;
m=111 actor="Harrison Ford" role="Indiana Jones" movie="Raiders of the Lost Ark" rating=4.8;
m=112 actor="Carrie Fisher" role=Marie movie="When Harry Met Sally" rating=4.3;

m=200 person="Mark Hamill" birthyear=1951 birthplace="Oakland, CA";
m=201 person="Harrison Ford" birthyear=1942 birthplace="Chicago, IL";
m=202 person="Carrie Fisher" birthyear=1956 birthplace="Burbank, CA";

m=300 place="Oakland, CA" population=433000 climate=Mediterranean foundedyear=1852;
m=301 place="Chicago, IL" population=2740000 climate="Humid Continental" foundedyear=1833;
m=302 place="Burbank, CA" population=105000 climate=Mediterranean foundedyear=1887;
```

### EBNF Memes

The EBNF below is a machine-readable description of stored memes.

```EBNF
(* Memelang v7 *)
memelang	::= { meme } ;
meme		::= mid { WS+ pair } WS* ';' ( WS | comment )* ;
mid			::= 'm' '=' id ;
pair		::= key '=' value ;
key			::= ALNUM+ ;
id			::= DIGIT+ ;
value		::= ['-'] DIGIT+ ['.' DIGIT+]? | ALNUM+ | quoted ;
quoted		::= '"' ( CHAR | '""' )* '"' ;
comment		::= '//' CHAR* ( '\n' | EOF ) ;
ALNUM		::= 'A'..'Z' | 'a'..'z' | DIGIT | '_' ;
DIGIT		::= '0'..'9' ;
WS			::= ' ' | '\t' | '\r' | '\n' ;
CHAR		::= ? any Unicode character except '"' or '\n' ? ;
```

## Queries

Queries are memes with uncertainty. The meme pair format `key=value` is a special *certainty* case of the more general query pair format `<keyopr><keys><valopr><values>`. Each query pair returns at least one certainty pair in the result.

### Key Operator (keyopr)
* *none* matches the listed keys `key=value`
* `!` matches any *except* the listed keys `!key=value`

### Keys
* Single **key** matches exactly `key=value`
* Wildcard matches any **key** for given **values** `*=value`
* Comma-separated list of **keys** matches any listed key `key,key2=value`
* Variable (explained below)

### Value Operator (valopr)
* `=`
* `!=`
* `>`
* `>=`
* `<`
* `<=`

### Values
* Single **value** matches exactly `key=value`
* Wildcard matches any **value** for given **keys** `key=*`
* Comma-separated list of **values** matches any listed value `key=Mark,"Mark Hamill"`
* Variable (explained below)


### Example Queries

```memelang
// Query for all movies with Mark Hamill as an actor
actor="Mark Hamill" movie=* role=*;

// Response
m=100 actor="Mark Hamill" movie="Star Wars" role="Luke Skywalker";
m=110 actor="Mark Hamill" movie="Batman: Mask of the Phantasm" role=Joker;
```
```memelang
// Query for all relations and values from all memes relating to Mark Hamill
// All pairs in the meme match for *=*
*="Mark Hamill" *=*;
```
```memelang
// Query for value inequalities
population>100000 place=*;
rating>=4.3 rating<=4.7 actor=* role=*;
```

### Example OR/Negation Queries
* `!` key operator negates all **keys** in the list
* `!=` value operator negates all **values** in the list

```memelang
// OR–list semantics in set notation
K1,K2=V1,V2;	// (key ∈ {K1,K2}) ∧ (value ∈ {V1,V2})
K1,K2!=V1,V2;	// (key ∈ {K1,K2}) ∧ (value ∉ {V1,V2})
!K1,K2=V1,V2;	// (key ∉ {K1,K2}) ∧ (value ∈ {V1,V2})
!K1,K2!=V1,V2;	// (key ∉ {K1,K2}) ∧ (value ∉ {V1,V2})
!K1,K2>V1;		// (key ∉ {K1,K2}) ∧ (value > V1)
```
```memelang
// Query for (actor OR role) = ("Luke Skywalker" OR "Mark Hamill")
actor,role="Luke Skywalker","Mark Hamill" movie=*;
```
```memelang
// Query for actors who are not Mark Hamill or Carrie Fisher
actor!="Mark Hamill","Carrie Fisher" role=* movie=*;
```
```memelang
// Query for Mark Hamill for all keys except actor and role
!actor,role="Mark Hamill" movie=*;
```

### EBNF Queries

The continued EBNF below is a machine-readable description of query pairs.

```EBNF
(* Memelang v7 - reuse grammar above *)
qmemelang	::= { qmeme } ;
qmeme		::= qpair { WS+ qpair } WS* ';' ( WS | comment )* ;
qpair 		::= pair | qkv ;
qkv			::= [keyopr] qkey {',' qkey} valopr qvalue {',' qvalue} ;
keyopr		::= '!' ;
valopr		::= '=' | '!=' | '<' | '<=' | '>' | '>=';
qkey		::= '*' | key | var ;
qvalue		::= '*' | value | var ;
var			::= '@' ALNUM+ [ ':' DIGIT+ ] ;
```

## Variables
Below is a simplified model of Memelang variables in Python.

```python
keys = [None]   # start at ordinal 𝑛=1
values = [None] # start at ordinal 𝑛=1
keynames = {}

def var_add (key, value):
	keys.append(key)
	values.append(value)
	keynames[key.lower()]=value

def var_get (tok):
	if tok.startswith('00'): return keys[int(tok[2:])]
	if tok.startswith('0'):  return values[int(tok[1:])]
	if tok.startswith('@'):  return keynames[tok[1:].lower()]
	return tok
```

* Variables *only* back-reference.
* Variables *cannot* be assigned
* Variables *cannot* forward-reference
* Variables *cannot* be inside quotes

### Keyname Variables
`@keyname` references the **value** from the last `keyname` pair.
* Case-insensitive
* Only populated when `keyname` is a single string (no `*` `!` `,`)
* This form is less token-efficient, more human readable

### Ordinals
Each query pair's returned **key** (string) and **value** (int, float, string) may be later back-referenced according to the pair's ordinal {𝑛|𝑛∈ℕ⁺} in the query.
* Start counting ordinal 𝑛 at the beginning of the query (semicolon or BOF)
* The first pair's ordinal is 𝑛=1
* For each following pair ordinal increments one 𝑛++
* Ordinals reset at the query end (semicolon or EOF)

```memelang
// Ordinal positions
actor="Mark Hamill" // 𝑛=1
movie=* // 𝑛=2
role=* // 𝑛=3
;
actor="Harrison Ford" // 𝑛=1
role=* // 𝑛=2
movie=* // 𝑛=3
;
```

### Ordinal Values
* `0𝑛` references **value** from the 𝑛th ordinal pair
* `0` is the variable sigil
* `01` references the 1st query pair's returned **value**
* `02` references the 2nd query pair's returned **value**
* `03` references the 3rd query pair's returned **value**
* `010` references the 10th query pair's returned **value**
* `011` references the 11th query pair's returned **value**
* More token-efficient than `@keyname`, less human readable
* Populated even when **key** is uncertain

### Ordinal Keys
* `00𝑛` references **key** at the 𝑛th ordinal pair
* `00` is the variable sigil
* `001` references the 1st query pair's returned **key**
* `002` references the 2nd query pair's returned **key**
* `003` references the 3rd query pair's returned **key**
* `0010` references the 10th query pair's returned **key**
* `0011` references the 11th query pair's returned **key**

Examples variable values after the given pair.

| First query pair | `001` | `01` | `@movie` |
|------------------|------|------|----------|
| `movie="Star Wars"` | movie | Star Wars | Star Wars |
| `movie=` | movie | *returned value* | *returned value* |
| `*="Star Wars"` | *returned key* | Star Wars | *(not populated)* |


### Variable Examples

Variables are primarily used in joins (section below). However, variables occasionally back-reference a pair from the current meme. Below are unusual examples of back-referencing the current meme (expert only, avoid).

```memelang
// Query for titular roles whose value equals the movie title
role=* movie=@role actor=*;
role=* actor=* movie=@role;
role=* movie=01 actor=*; // role=* is 𝑛=01
actor=* role=* movie=02; // role=* is 𝑛=02
```
```memelang
// Variables may be used in comma lists
role=* movie=01,"Star Wars";
```
```memelang
// Variables may swap value into key name
K1=* 01=V2; // 01 must be alphanumeric
K1=* @K1=V2;
```
```memelang
// Variables may swap key name into value
*=V1 K2=001;
```

## Joins

Distinct items (actors, movies, etc.) usually occupy distinct memes with unique `m=id` identifiers. By default, a query pair stays within the current meme. A join query matches multiple memes by specifying a pair with **key** `m`, allowing the next query pair to match a different meme.
* `m` **key** in a query pair specifies which memes to join next
* `@m` is automatically implicitly populated with the current `m=<id>`
* `m=@m` stay in current meme (implicit default)
* `m!=@m` join to a different meme
* `m=*` join to any meme (current or different)

*Always* after an `m` pair, the following pair back-references an uncertain query pair from the prior meme.

### Distinct Joins

```memelang
// The most common join is distinct
K1=* m!=@m K2=@K1
```
Explained:
* `K1=*` a first meme has a pair
	* **key** equals `K1`
	* any **value** populates `@K1`
* `m!=@m` requires the following pair matches a *distinct* meme identifier
* `K2=@K1` requires the second meme has a pair 
	* **key** equals `K2` 
	* **value** equals `K1`'s **value**

Note `m!=@m` joins to *distinct* memes, so trailing distinct conditionals like `actor!=@actor` are redundant and unnecessary.


### Indistinct Joins

```memelang
// Wildcard allows the current meme in the second joined meme 
K1=* m=* K2=@K1
```

### Wildcard Key Joins

```memelang
// Wildcards in keys
*=* m!=@m *=01
```
Explained:
* `*=*` matches every **key** and **value** in a first meme
	* any **value** populates `01`
* `m!=@m` requires the following pair matches a *distinct* meme identifier
* `*=01` requires the second meme has a pair with 
	* **key** equals anything
	* **value** equals `01` the **value** of the first pair (`*=*`)
	* 𝑛=1 here, but changes based on query position

### Join Examples

```memelang
// Query for all of Mark Hamill's costars - see how 02 and 03 and @movie each reference movie=* in their respective queries
actor="Mark Hamill" movie=* m!=@m movie=@movie actor=*;
movie=* actor="Mark Hamill" m!=@m movie=@movie actor=*;
actor="Mark Hamill" movie=* m!=@m movie=02 actor=*; // 𝑛=2 references movie=*
movie=* actor="Mark Hamill" m!=@m movie=01 actor=*; // 𝑛=1 references movie=*

// Response - join queries return combined memes, each pair belongs to the preceding m=<id>
m=100 actor="Mark Hamill" movie="Star Wars" m=101 movie="Star Wars" actor="Harrison Ford";
m=100 actor="Mark Hamill" movie="Star Wars" m=102 movie="Star Wars" actor="Carrie Fisher";
```
```memelang
// Query for the actor's birthplace
actor=* m!=@m person=@actor birthplace=*;
actor=* m!=@m person=01 birthplace=*;
```
```memelang
// Query for people born in the year their birthplace was founded - join on int birthyear is year = foundedyear is year
person=* birthyear=* m!=@m foundedyear=@birthyear place=*;
person=* birthyear=* m!=@m foundedyear=02 place=*;
```
```memelang
// Query for every meme related to any value related to Mark Hamill - wild join keys (expert, avoid)
actor="Mark Hamill" *=* m!=@m *=02 *=*;
```

### Multi-join Examples

```memelang
// Query for the other movies Mark Hamill's costars have acted in - multi join
actor="Mark Hamill" movie=* m!=@m movie=@movie actor=* m!=@m actor=@actor movie=*;
actor="Mark Hamill" movie=* m!=@m movie=02 actor=* m!=@m actor=05 movie=*;
```
```memelang
// Query for the population of the birthplace of the Star Wars cast
movie="Star Wars" actor=* m!=@m person=@actor birthplace=* m!=@m place=@birthplace population=*;
movie="Star Wars" actor=* m!=@m person=02 birthplace=* m!=@m place=05 population=*;
```
```memelang
// Query for cities older than Burbank and with larger populations - inequality join
place="Burbank, CA" foundedyear=* population=* m!=@m population>@population foundedyear<@foundedyear place=*;
place="Burbank, CA" foundedyear=* population=* m!=@m population>03 foundedyear<02 place=*; // 𝑛=02 -> Burbank foundedyear -> 1887
```

## Failure Modes

### Syntax Failures

```memelang
// Syntax Error - cannot chain values
K1=V1=V2;
```
```memelang
// Syntax Error - missing spaces between pairs
K1=*K2=*K3=X;
```
```memelang
// Syntax Error - cannot mix wildcard and commas
K1=*,V1,V2;
```
```memelang
// Syntax Error - invalid variable @*
*=V1 K2=@*
```
```memelang
// Warning - wildcard inside quotes - becomes literal "*"
actor="*";

// Likely meant
actor=*;
```
```memelang
// Warning - variable inside quotes
person=* m!=@m actor="@person";

// Likely meant
person=* m!=@m actor=@person;
```
```memelang
// Warning - redundant birthyear pair
birthyear=* birthyear<2000;

// Likely meant - returns birthyear value
birthyear<2000
```

### Join Failures

```memelang
// Warning - missing m= pair in join
movie=* movie=01;

// Likely meant
movie=* m!=@m movie=01;
```
```memelang
// Warning - missing back-reference variable
movie=* m!=@m actor=*;

// Likely meant
movie=* m!=@m movie=01 actor=*;
```
```memelang
// Warning - wrong ordinal - 01 references m!=@m pair
movie=* m!=@m movie=02;

// Likely meant
movie=* m!=@m movie=01;
```
```memelang
// Warning - wrong ordinal - 01 references m!=@m pair
movie=* m!=@m movie=03;

// Likely meant
movie=* m!=@m movie=01;
```
```memelang
// Warning - must join similar values - actor is person != birthplace is place
birthplace=* person=* m!=@m actor=@birthplace;

// Likely meant
person=* m!=@m actor=@person birthplace=*;
```
```memelang
// Semantic Error - undefined variable @director
movie=* m!=@m actor=@director;

// Likely meant
director=* movie=* m!=@m actor=@director;
```

## SQL Comparisons

Memelang queries are significantly shorter and clearer than equivalent SQL queries.

```memelang
actor=* role="Luke Skywalker","Han Solo" rating>4;
```
```sql
SELECT actor FROM movies WHERE role IN ('Luke Skywalker', 'Han Solo') AND rating > 4;
```

```memelang
person,actor="Mark Hamill","Harrison Ford" movie=* m!=@m movie=@movie actor=*;
```
```sql
SELECT m1.actor, m1.movie, m2.actor FROM movies m1 JOIN movies m2 ON m1.movie = m2.movie WHERE m1.person IN ('Mark Hamill', 'Harrison Ford') AND m1.actor IN ('Mark Hamill', 'Harrison Ford');
```

## Credits

Memelang was created by [Bri Holt](https://en.wikipedia.org/wiki/Bri_Holt) in a [2023 U.S. Provisional Patent application](https://patents.google.com/patent/US20250068615A1). ©2025 HOLTWORK LLC. Contact [info@memelang.net](mailto:info@memelang.net).