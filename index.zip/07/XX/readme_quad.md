# Memelang v7

Memelang is an AI-optimized language for querying structured data, knowledge graphs, and retrieval-augmented generation pipelines.

## Memes

* Comprises key-value pairs `<key><opr><values>` such as `K1=V1`
* Pairs must be separated by whitespaces `\s+`
* First pair always identifies the meme `m=<id>`
* Must terminate with semicolon `;`

### Key
* Alphanumeric string `movie`
	* Must contain at least one `[A-Za-z]`
* Variable (explained below)
* Wildcard key `*`
* Meta key `_`
	* Not executed, solely for later reference

### Operator
* `=`
* `!=`
* `>`
* `>=`
* `<`
* `<=`

### Values
* Single **value**
	* Integer `-123`
	* Float `45.6`
	* Alphanumeric unquoted string `Leia`
	* CSV-style double quoted string `"Anakin ""Ani"" Skywalker"`
	* Variable (explained below)
* Comma-separated **value** list `Leia,"Anakin ""Ani"" Skywalker"`
* Wildcard value `*`

### Comment
* Prefixed with double forward slashes `//`
* Terminated with newline `\n`

### Examples

#### Stored Memes

```memelang
m=100 k=actor v="Mark Hamill" k=role v="Luke Skywalker" k=movie v="Star Wars" k=rating v=4.5;
m=101 k=actor v="Harrison Ford" k=role v="Han Solo" k=movie v="Star Wars" k=rating v=4.6;
m=102 k=actor v="Carrie Fisher" k=role v=Leia k=movie v="Star Wars" k=rating v=4.2;

m=110 k=actor v="Mark Hamill" k=role v=Joker k=movie v="Batman: Mask of the Phantasm" k=rating v=4.7;
m=111 k=actor v="Harrison Ford" k=role v="Indiana Jones" k=movie v="Raiders of the Lost Ark" k=rating v=4.8;
m=112 k=actor v="Carrie Fisher" k=role v=Marie k=movie v="When Harry Met Sally" k=rating v=4.3;

m=200 k=person v="Mark Hamill" k=birthyear v=1951 k=birthplace v="Oakland, CA";
m=201 k=person v="Harrison Ford" k=birthyear v=1942 k=birthplace v="Chicago, IL";
m=202 k=person v="Carrie Fisher" k=birthyear v=1956 k=birthplace v="Burbank, CA";

m=300 k=place v="Oakland, CA" k=population v=433000 k=climate v=Mediterranean k=foundedyear v=1852;
m=301 k=place v="Chicago, IL" k=population v=2740000 k=climate v="Humid Continental" k=foundedyear v=1833;
m=302 k=place v="Burbank, CA" k=population v=105000 k=climate v=Mediterranean k=foundedyear v=1887;
```

#### Query Memes

Query memes introduce uncertainty.

```memelang
// All movies with Mark Hamill as an actor
k=actor v="Mark Hamill" k=movie v=* k=rating v>4 k=role v=*;

// Response
m=100 k=actor v="Mark Hamill" k=movie v="Star Wars" k=rating v=4.5 k=role v="Luke Skywalker";
m=110 k=actor v="Mark Hamill" k=movie v="Batman: Mask of the Phantasm" k=rating v=4.7 k=role v=Joker;
```
```memelang
// All keys and values from all memes relating to Mark Hamill
// k=* v=* matches all pairs in the meme
k=* v="Mark Hamill" k=* v=*;
```

## Variables
Variables let later pairs retrieve the **keys** (list of strings) and **values** (list of integers/floats/strings) returned from prior pairs.
* Variables *cannot* be assigned.
* Variables *cannot* forward-reference.
* Variables *cannot* reference objects or properties.
* Variables *cannot* be inside quotes.

### Variable Arrays
Simplified variable model in python:
```python
variables = {'V':[]}

def var_add(keys: list, values: list):
	variables['V'].append(values)
	if len(keys)==1: variables.setdefault(keys[0].lower(), []).append(values)

def index_get(n: str) -> int:
	if len(n)<1: return 1
	return int(n)

def var_get(tok):
	for sigil, mult, offset in (('#',1,-1), ('@',-1,0)):
		if tok.startswith(sigil):
			if tok[1:].isdigit(): return variables['V'][mult*index_get(tok[1:])+offset]
			name, _, p = tok[1:].partition(':')
			return variables[name.lower()][mult*index_get(p)+offset]
```

How the variable arrays grow while processing the query:
```memelang
k=movie v="Star Wars"	// 𝑝=1; variables={'V': [['Star Wars']], 'movie': [['Star Wars']]}
k=role v=*				// 𝑝=2; variables={'V': [['Star Wars'], [V1, V2, …]], 'movie': [['Star Wars']], 'role': [[V1, V2, …]]}
k=* v>4.5;				// 𝑝=3; variables={'V': [['Star Wars'], [V1, V2, …], [4.5]], 'movie': [['Star Wars']], 'role': [[V1, V2, …]]}
```

### Forward-Indexes
* Sigils `#` and use absolute forward-indexing 𝑝
* Forward-index 𝑝 is a pair's absolute left-to-right query position
* Easy for AIs to count, hard for humans to maintain
* 𝑝=0 after `;` (or BOF)
* 𝑝++ for every query pair (including `m` and `->` pairs below)
* 𝑝=1 is the first pair
* 𝑝=2 is the second pair

#### Forward-Index Values
* `#𝑝` retrieves the **values** from the 𝑝th pair
* `#1` retrieves the **values** from the first pair 
* `#2` retrieves the **values** from the second pair

#### Forward-Index Keyname Values
* `#keyname:𝑝` retrieves the **values** from the 𝑝th `keyname` pair
* `#keyname` and `#keyname:1` retrieve the **values** from the first `keyname` pair
* *Only* populates when query **keys** is a single string (no `*` `@` `#`)
* Case-insensitive

### Backward-Indexes
* Sigils `@` and use relative backward-indexing 𝑞
* Backward-index 𝑞 counts backward from the current pair's query position 𝑞 = 𝑝₂ − 𝑝₁
* Harder for AIs to count, easier for humans to maintain
* 𝑞=0 is current pair (*illegal*)
* 𝑞++ for every query pair back (including `m` and `->` pairs below)
* 𝑞=1 is the first pair back
* 𝑞=2 is the second pair back

#### Backward-Index Values
* `@𝑞` retrieves the **values** from the 𝑞th pair back
* `@1` and `@` retrieves the **values** from the first pair back 
* `@2` retrieves the **values** from the second pair back

#### Backward-Index Keyname Values
* `@keyname:𝑞` retrieves the **values** from the 𝑞th prior `keyname` pair
* `@keyname` and `@keyname:1` retrieve the **values** from the last `keyname` pair
* *Only* populates when query **keys** is a single string (no `*` `@` `#`)
* Case-insensitive

### Example Variables
Variables primarily retrieve prior pairs in joins (section below). However, variables occasionally retrieve pairs from the current meme (expert only, avoid).

```memelang
// Titular roles whose value equals the movie title
// Every variable retrieves k=role v=*
k=role v=* k=actor v=* k=movie v=@role;
k=role v=* k=actor v=* k=movie v=#role;
k=role v=* k=actor v=* k=movie v=@2;
k=role v=* k=actor v=* k=movie v=#1;
k=actor v=* k=role v=* k=movie v=@role;
k=actor v=* k=role v=* k=movie v=#role;
k=actor v=* k=role v=* k=movie v=@1;
k=actor v=* k=role v=* k=movie v=#2;
```
```memelang
// Variable in comma list
k=role v=* k=movie v=@1,"Star Wars";
```
```memelang
// Actors who are not Mark Hamill or Carrie Fisher
k=actor v!="Mark Hamill","Carrie Fisher" k=role v=* k=movie v=*;
```
```memelang
// FAILURE
k=actor v="@person"; // Warning: variable inside quotes
k=actor v=@person; // Likely meant
```


## Joins
Distinct items (actors, movies, etc.) usually occupy distinct memes with unique `m=id` identifiers. By default, a pair stays within the current meme. A join query matches multiple memes by specifying a pair with **key** `m`, allowing the next pair to match a different meme.
* `m` **key** in a pair specifies which memes to join next
* `@m` is automatically populated with the current `m=<id>`
* `m=@m` and `m=@m:1` stay in current meme (implicit default)
* `m!=@m` (shorthand `->`) join to a different meme
* `m=*` join to any meme (current or different)

### Join Variables
*Always* after an `m` pair, the following pair retrieves an uncertain pair from the prior meme.
* Generally using `@keyname` is preferred
	* The preceeding meme ***MUST*** have a pair with key `keyname`
* When `@keyname` is unpopulated, the correct **value** variable is generally `@3`
* For `v=@K1`, `K1` and `K2` *must* have semantically similar **values**, such as person↔person or year↔year, *not* person↔year
* `m!=@m` joins to *distinct* memes, so trailing distinct conditionals like `k=actor v!=@actor` are generally redundant

```memelang
// The most common join is distinct
k=K1 v=*	// pair in first meme
m!=@m	// next pair must match a distinct meme
k=K2 v=@K1;	// pair in second meme, where K2 and K1 share a value
```
```memelang
// Wildcard m allows the current meme in the second joined meme 
k=K1 v=*	// pair in first meme
m=*		// next pair may match any meme
k=K2 v=@K1;	// pair in second meme, where K2 and K1 share a value
```
```memelang
// Wildcards in keys
k=* v=*		// every pair in first meme
->		// (shorthand for m!=@m) next pair must match a distinct meme
k=* v=@3;	// pair in second meme, any key has value from first meme
```

### Example Joins
```memelang
// All of Mark Hamill's costars - see how variables retrieve k=movie v=* in their respective queries
// Each variable retrieves k=movie v=*
k=actor v="Mark Hamill" k=movie v=* -> k=movie v=@movie k=actor v=*;
k=movie v=* k=actor v="Mark Hamill" -> k=movie v=@movie k=actor v=*;
k=actor v="Mark Hamill" k=movie v=* -> k=movie v=@2 k=actor v=*; 
k=movie v=* k=actor v="Mark Hamill" -> k=movie v=@3 k=actor v=*;
k=actor v="Mark Hamill" k=movie v=* -> k=movie v=#2 k=actor v=*;
k=movie v=* k=actor v="Mark Hamill" -> k=movie v=#1 k=actor v=*;

// Response - join queries return concatenated memes, each pair belongs to the preceding m=<id>
m=100 k=actor v="Mark Hamill" k=movie v="Star Wars" m=101 k=movie v="Star Wars" k=actor v="Harrison Ford";
m=100 k=actor v="Mark Hamill" k=movie v="Star Wars" m=102 k=movie v="Star Wars" k=actor v="Carrie Fisher";
```
```memelang
// People born in the year their birthplace was founded - join on int birthyear is year = foundedyear is year
k=person v=* k=birthyear v=* -> k=foundedyear v=@birthyear k=place v=*;
k=person v=* k=birthyear v=* -> k=foundedyear v=@2 k=place v=*;
```
```memelang
// Every meme related to any value related to Mark Hamill - wild join keys (expert, avoid)
k=actor v="Mark Hamill" k=* v=* -> k=* v=@2 k=* v=*;
```

### Example Multi-joins
```memelang
// Other movies Mark Hamill's costars have acted in - multi join
k=actor v="Mark Hamill" k=movie v=* -> k=movie v=@movie k=actor v=* -> k=actor v=@actor k=movie v=*;
k=actor v="Mark Hamill" k=movie v=* -> k=movie v=@2 k=actor v=* -> k=actor v=@2 k=movie v=*;
```
```memelang
// Population of the birthplace of the Star Wars cast
k=movie v="Star Wars" k=actor v=* -> k=person v=@actor k=birthplace v=* -> k=place v=@birthplace k=population v=*;
k=movie v="Star Wars" k=actor v=* -> k=person v=@2 k=birthplace v=* -> k=place v=@2 k=population v=*;
```
```memelang
// Cities older than Burbank and with larger populations - inequality join
k=place v="Burbank, CA" k=foundedyear v=* k=population v=* -> k=population v>@population k=foundedyear v<@foundedyear k=place v=*;
k=place v="Burbank, CA" k=foundedyear v=* k=population v=* -> k=population v>@2 k=foundedyear v<@4 k=place v=*; // @4 = 1887 (Burbank foundedyear)
```


## Credits
[Bri Holt](mailto:info@memelang.net) · [Patents Pending](https://patents.google.com/patent/US20250068615A1) · ©2025 HOLTWORK LLC